module.exports = {
  info: {
    // API informations (required)
    title: "Patient API Doc", // Title (required)
    version: "1.0.0", // Version (required)
    description: "API's For Patient Data" // Description (optional)
  },
  //host:'localhost:9000', // Host (optional)
  basePath: "/", // Base path (optional)
  apis: ["./routes/*.js"] // <-- We add this property:
};
