var express = require("express");
var router = express.Router();
import Config from "../config/config";
const request = require('request');
const { externalApiRootUrl,responseCode } = Config;
/************Start GET Patient Data API ************************* */
/**
 * @swagger
 * /api/patientdata:
 *   get:
 *     tags:
 *       - Get Patient Data
 *     description: Returns a paitent list according to params
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: name
 *         in:  query
 *         type: string
 *       - name: phone
 *         in:  query
 *         type: string
 *       - name: city
 *         in:  query
 *         type: string
 *       - name: country
 *         in:  query
 *         type: string
 *     responses:
 *       200:
 *         description: Array list of cnds
 *         schema:
 *          type: object
 *          properties:
 *           status:
 *            type: string
 *           totalRecCount:
 *            type: integer
 *           result:
 *            type: array
 *            items:
 *             type: object
 *
 *
 */
/************* Patient Data API****************/
router.get("/api/patientdata",function (req, res) {
  console.log("query",req.query)
  let dbquery = '';
  let limit =50;
  if (req.query.name) 
    dbquery += '&name='+req.query.name;

    if (req.query.phone) 
    dbquery += '&phone='+req.query.phone;

    if (req.query.city) 
    dbquery += '&address-city='+req.query.city;

    if (req.query.country) 
    dbquery += '&address-country='+req.query.country;
  
    if (req.query.sortBy){
      dbquery += '&_sort='+req.query.sortBy;
    }else{
      dbquery += '&_sort=_id';
    }

    if (req.query.limit){
      limit = req.query.limit;
    }

    dbquery += '&_count='+limit;
    

   request(externalApiRootUrl+dbquery, (err, response, body,_res) => {
    if (err) { 
      res.status(responseCode.error).json({
      success: false,
      responseCode: responseCode.error,
      result: "Error fetching data",
      msg: err,
    });
  }
    if(response.statusCode == responseCode.success){
      var resultData = JSON.parse(body);
      res.status(responseCode.success).json({
        success: true,
        responseCode: response.statusCode,
        total: resultData.total,
        result: resultData.entry,
        link : resultData.link,
        limit: limit,
        msg: "Patient data fetched successfully", // Msg also can be configured
      });
    }else{
      res.status(response.statusCode).json({
        success: true,
        responseCode: response.statusCode,
        details: JSON.parse(body),
        msg: "Plz check details!", // Msg also can be configured
    });
    }
      
  });
});
/************End  API ************************* */

module.exports = router;
