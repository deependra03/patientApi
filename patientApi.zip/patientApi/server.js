import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import Config from "./config/config";
var patients = require("./routes/patients");
var swaggerJSDoc = require("swagger-jsdoc");
var swaggerUi = require("swagger-ui-express"),
  swaggerDocument = require("./swagger.json");
var app = express();

const { port } = Config;

app.get("/", (req, res) => {
  res.json({ status: "OK" });
});


app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "http://localhost:3000");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");

  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept,x-auth-token,x-refresh-token"
  );
  next();
});

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept,x-auth-token,x-refresh-token"
  );
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");

  next();
});


app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));
//app.use('/api-docs', swaggerDocCreate);
//app.use('/api/v1', router);
app.use(express.static("public"));
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use("/", patients);

// Start the server
app.listen(port, function () {
  console.log("Server is running on Port: ", port);
});

module.exports = app;
