
const port = process.env.PORT || 5008;
const externalApiRootUrl ='http://test.fhir.org/r4/Patient?_format=json';
const responseCode = {
  success: 200,
  badrequest: 400,
  unauthorized: 401,
  forbidden: 403,
  notFound : 400,
  error:500,
  serviceunavailable: 503
};

export default {
  port,
  externalApiRootUrl,
  responseCode
};
